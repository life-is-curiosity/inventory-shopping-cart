create
    definer = root@localhost procedure dataSyncTexTrade()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE s VARCHAR(25);
    DECLARE tradeCursor CURSOR FOR SELECT DISTINCT symbol FROM tex_trades;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SET @dbName = 'exchange';

    OPEN tradeCursor;

    fetch_loop: LOOP
        FETCH tradeCursor INTO s;
        IF done THEN
            LEAVE fetch_loop;
        END IF;

        SET @tradeTableName = CONCAT('ex_trade_', LOWER(REPLACE(s, '_', '')));

        IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@dbName AND TABLE_NAME=@tradeTableName) THEN
            SET @createTradeTableSql = CONCAT('CREATE TABLE IF NOT EXISTS exchange.', @tradeTableName, ' (LIKE exchange.ex_trade_ethbtc);');
            PREPARE createTradeTableStmt FROM @createTradeTableSql;
            EXECUTE createTradeTableStmt;
            DEALLOCATE PREPARE createTradeTableStmt;
        END IF;

        # Update the orders
        SET @updateMainTradeTable = CONCAT(
        'INSERT INTO     ', @tradeTableName, '
                        (
                            id, price, volume, bid_id, ask_id, trend_side, bid_user_id, ask_user_id,
                            buy_fee, sell_fee, buy_fee_coin, sell_fee_coin, ctime, mtime
                        )
        SELECT  trade_id, price, volume, bid_id, ask_id, trend_side, bid_user_id, ask_user_id,
                buy_fee, sell_fee, buy_fee_coin, sell_fee_coin, ctime, mtime
        FROM    tex_trades textrd
        WHERE   textrd.symbol = \'', s, '\'
        ON DUPLICATE KEY UPDATE
                                price = textrd.price,
                                volume = textrd.volume,
                                buy_fee = textrd.buy_fee,
                                sell_fee = textrd.sell_fee,
                                buy_fee_coin = textrd.buy_fee_coin,
                                sell_fee_coin = textrd.sell_fee_coin,
                                mtime = textrd.mtime;'
        );
        PREPARE updateMainTradeTableStmt FROM @updateMainTradeTable;
        EXECUTE updateMainTradeTableStmt;
        DEALLOCATE PREPARE updateMainTradeTableStmt;

    END LOOP;
    CLOSE tradeCursor;
END;

