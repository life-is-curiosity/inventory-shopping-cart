create
    definer = root@localhost procedure insertTexTrade(IN pSymbol varchar(50), IN pTradeIdChainup bigint,
                                                      IN pPrice decimal(32, 16) unsigned,
                                                      IN pVolume decimal(32, 16) unsigned, IN pBuyOrderIdTex bigint,
                                                      IN pSellOrderIdTex bigint, IN pTrendSide varchar(4),
                                                      IN pBidUserId int unsigned, IN pAskUserId int unsigned,
                                                      IN pBuyFee decimal(32, 16) unsigned,
                                                      IN pSellFee decimal(32, 16) unsigned, IN pBuyFeeCoin varchar(50),
                                                      IN pSellFeeCoin varchar(50), IN pCtime timestamp,
                                                      IN pMtime timestamp)
BEGIN
  SET @query = CONCAT('INSERT INTO `exchange`.`ex_trade_', pSymbol, '`(`id`, `price`, `volume`, `bid_id`, `ask_id`, `trend_side`, `bid_user_id`, `ask_user_id`, `buy_fee`, `sell_fee`, `buy_fee_coin`, `sell_fee_coin`, `ctime`, `mtime`) VALUES(?, ?, ?, (SELECT `chainup_id` FROM `exchange`.`tex_id` WHERE `symbol`=''', pSymbol, ''' AND `id_type`=''ORDERID'' AND `tex_id`=', pBuyOrderIdTex, '), (SELECT `chainup_id` FROM `exchange`.`tex_id` WHERE `symbol`=''', pSymbol, ''' AND `id_type`=''ORDERID'' AND `tex_id`=', pSellOrderIdTex, '), ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  SET @p1 = pTradeIdChainup;
  SET @p2 = pPrice;
  SET @p3 = pVolume;
  SET @p4 = pTrendSide;
  SET @p5 = pBidUserId;
  SET @p6 = pAskUserId;
  SET @p7 = pBuyFee;
  SET @p8 = pSellFee;
  SET @p9 = pBuyFeeCoin;
  SET @p10 = pSellFeeCoin;
  SET @p11 = pCtime;
  SET @p12 = pMtime;
  PREPARE stmt FROM @query;
  EXECUTE stmt USING @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12;
END;

