create
    definer = root@localhost procedure insertTexOrder(IN pSymbol varchar(50), IN pOrderIdTex bigint,
                                                      IN pOrderIdChainup bigint, IN pUserId int unsigned,
                                                      IN pSide varchar(4), IN pPrice decimal(32, 16) unsigned,
                                                      IN pVolume decimal(32, 16) unsigned,
                                                      IN pFeeRateMaker double unsigned,
                                                      IN pFeeRateTaker double unsigned,
                                                      IN pDealVolume decimal(32, 16) unsigned,
                                                      IN pDealMoney decimal(32, 16) unsigned,
                                                      IN pAvgPrice decimal(32, 16) unsigned,
                                                      IN pStatus tinyint unsigned, IN pType tinyint unsigned,
                                                      IN pSource tinyint unsigned, IN pCtime timestamp,
                                                      IN pMtime timestamp)
BEGIN
  IF pOrderIdChainup IS NOT NULL THEN
    SET @query = CONCAT('INSERT INTO `exchange`.`ex_order_', pSymbol, '`(`id`, `user_id`, `side`, `price`, `volume`, `fee_rate_maker`, `fee_rate_taker`, `deal_volume`, `deal_money`, `avg_price`,`status`, `type`, `source`, `ctime`, `mtime`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    SET @p1 = pOrderIdChainup;
    SET @p2 = pUserId;
    SET @p3 = pSide;
    SET @p4 = pPrice;
    SET @p5 = pVolume;
    SET @p6 = pFeeRateMaker;
    SET @p7 = pFeeRateTaker;
    SET @p8 = pDealVolume;
    SET @p9 = pDealMoney;
    SET @p10 = pAvgPrice;
    SET @p11 = pStatus;
    SET @p12 = pType;
    SET @p13 = pSource;
    SET @p14 = pCtime;
    SET @p15 = pMtime;
    PREPARE stmt FROM @query;
    EXECUTE stmt USING @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12, @p13, @p14, @p15;
  ELSE
    SET @query = CONCAT('UPDATE `exchange`.`ex_order_', pSymbol, '` SET `status`=?, `deal_volume`=?, `deal_money`=?, `avg_price`=?, `mtime`=? WHERE `id`=(SELECT `chainup_id` FROM `exchange`.`tex_id` WHERE `symbol`=''', pSymbol, ''' AND `id_type`=''ORDERID'' AND `tex_id`=', pOrderIdTex, ')');
    SET @p1 = pStatus;
    SET @p2 = pDealVolume;
    SET @p3 = pDealMoney;
    SET @p4 = pAvgPrice;
    SET @p5 = pMtime;
    PREPARE stmt FROM @query;
    EXECUTE stmt USING @p1, @p2, @p3, @p4, @p5;
  END IF;
END;

