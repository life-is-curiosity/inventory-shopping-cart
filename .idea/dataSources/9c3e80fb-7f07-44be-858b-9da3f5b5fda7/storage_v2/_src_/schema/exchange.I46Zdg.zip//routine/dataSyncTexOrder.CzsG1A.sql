create
    definer = root@localhost procedure dataSyncTexOrder()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE s VARCHAR(25);
    DECLARE orderCursor CURSOR FOR SELECT DISTINCT symbol FROM tex_orders;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SET @dbName = 'exchange';

    OPEN orderCursor;

    fetch_loop: LOOP
        FETCH orderCursor INTO s;
        IF done THEN
            LEAVE fetch_loop;
        END IF;

        SET @orderTableName = CONCAT('ex_order_', LOWER(REPLACE(s, '_', '')));

        IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@dbName AND TABLE_NAME=@orderTableName) THEN
            SET @createOrderTableSql = CONCAT('CREATE TABLE IF NOT EXISTS exchange.', @orderTableName, ' (LIKE exchange.ex_order_ethbtc);');
            PREPARE createOrderTableStmt FROM @createOrderTableSql;
            EXECUTE createOrderTableStmt;
            DEALLOCATE PREPARE createOrderTableStmt;
        END IF;

        # Update the orders
        SET @updateMainOrderTable = CONCAT(
        'INSERT INTO     ', @orderTableName, '
                        (
                            id, user_id, side, price, volume, fee_rate_maker, fee_rate_taker,
                            deal_volume, deal_money, avg_price, status, type, ctime, mtime, source
                        )
        SELECT  order_id, user_id, side, price, volume, fee_rate_maker, fee_rate_taker,
                deal_volume, deal_money, avg_price, status, type, ctime, mtime, source
        FROM    tex_orders texo
        WHERE   texo.symbol = \'', s, '\'
        ON DUPLICATE KEY UPDATE
                                fee_rate_maker = texo.fee_rate_maker,
                                fee_rate_taker = texo.fee_rate_taker,
                                deal_volume = texo.deal_volume,
                                deal_money = texo.deal_money,
                                avg_price = texo.avg_price,
                                status = texo.status,
                                mtime = texo.mtime;'
        );
        PREPARE updateMainOrderTableStmt FROM @updateMainOrderTable;
        EXECUTE updateMainOrderTableStmt;
        DEALLOCATE PREPARE updateMainOrderTableStmt;

    END LOOP;
    CLOSE orderCursor;
END;

